@javax.xml.bind.annotation.XmlSchema(namespace = "http://libservice/")
package libservice;
