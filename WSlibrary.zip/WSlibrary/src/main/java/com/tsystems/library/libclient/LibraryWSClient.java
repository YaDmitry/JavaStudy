package com.tsystems.library.libclient;


import com.tsystems.library.libservice.LibraryWS;

public class LibraryWSClient {

	private LibraryWS serverWebservice;

	public LibraryWSClient(LibraryWS serverWebservice) {
		this.serverWebservice = serverWebservice;
	}

	public boolean addUser(String name, String surname) {
		return serverWebservice.addUser(name, surname);
	}

}
